let goods = [
    { id: 1, name: "小米手机", price: 1999 },
    { id: 4, name: "华为电脑", price: 13999 },
    { id: 5, name: "华为手机", price: 4999 },
    { id: 2, name: "小米手环", price: 299 },
    { id: 3, name: "小米电脑", price: 2999 },
    { id: 6, name: "小猪佩奇", price: 49 },
    { id: 7, name: "小猪乔治", price: 99 }
];